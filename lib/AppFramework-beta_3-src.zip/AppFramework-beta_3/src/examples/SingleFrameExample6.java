/*
* Copyright (C) 2006 Sun Microsystems, Inc. All rights reserved. Use is
* subject to license terms.
*/

package examples;

import org.jdesktop.application.Action;
import org.jdesktop.application.SingleFrameApplication;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * A demo that shows the use of SingleFrameApplication secondary windows.
 *
 * @author Hans Muller (Hans.Muller@Sun.COM)
 */
public class SingleFrameExample6 extends SingleFrameApplication {
    private List<Window> windows;

    protected void initialize(String[] args) {
        windows = new ArrayList<Window>();
        windows.add(new JFrame());
        windows.add(new JDialog());
        windows.add(new JDialog());
        for (int i = 0; i < windows.size(); i++) {
            Window w = windows.get(i);
            JLabel label = new JLabel();
            JButton button = new JButton();
            button.setAction(getAction("hideWindow"));
            label.setName("label");
            button.setName("button");
            RootPaneContainer rpc = (RootPaneContainer) w;
            rpc.getContentPane().add(label, BorderLayout.CENTER);
            rpc.getContentPane().add(button, BorderLayout.SOUTH);
            configureWindow(w, "window" + i);
        }
    }

    @Action
    public void hideWindow(ActionEvent e) {
        if (e.getSource() instanceof Component) {
            Component source = (Component) e.getSource();
            Window window = SwingUtilities.getWindowAncestor(source);
            if (window != null) {
                window.setVisible(false);
            }
        }
    }

    @Action
    public void showWindow0() {
        windows.get(0).setVisible(true);
    }

    @Action
    public void showWindow1() {
        windows.get(1).setVisible(true);
    }

    @Action
    public void showWindow2() {
        windows.get(2).setVisible(true);
    }

    @Action
    public void disposeSecondaryWindows() {
        for (int i = 0; i < windows.size(); i++) {
            Window window = windows.get(i);
            if (window != null) {
                windows.set(i, null);
                window.dispose();
            }
        }
    }

    private javax.swing.Action getAction(String actionName) {
        return getContext().getActionMap().get(actionName);
    }

    private JMenu createMenu(String menuName, String[] actionNames) {
        JMenu menu = new JMenu();
        menu.setName(menuName);
        for (String actionName : actionNames) {
            if (actionName.equals("---")) {
                menu.add(new JSeparator());
            } else {
                JMenuItem menuItem = new JMenuItem();
                menuItem.setAction(getAction(actionName));
                menuItem.setIcon(null);
                menu.add(menuItem);
            }
        }
        return menu;
    }

    protected JMenuBar createJMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        String[] viewMenuActionNames = {
                "showWindow0",
                "showWindow1",
                "showWindow2",
                "disposeSecondaryWindows",
                "---",
                "quit"
        };
        menuBar.add(createMenu("viewMenu", viewMenuActionNames));
        return menuBar;
    }

    @Override
    protected Component createMainComponent() {
        JLabel label = new JLabel();
        label.setName("mainLabel");
        return label;
    }

    public static void main(String[] args) {
        launch(SingleFrameExample6.class, args);
    }
}
