package examples;

import org.jdesktop.application.Application;

import javax.swing.*;

public class SingleFrameExample2AsApplet extends JApplet {
    
    public void init() {
//        SingleFrameExample2 example2 = new SingleFrameExample2();
//        example2.launch(null);
//        setRootPane(example2.getMainTopLevel().getRootPane());
    }
}
