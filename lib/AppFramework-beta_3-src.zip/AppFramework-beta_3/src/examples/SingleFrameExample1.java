/*
* Copyright (C) 2006 Sun Microsystems, Inc. All rights reserved. Use is
* subject to license terms.
*/

package examples;

import org.jdesktop.application.SingleFrameApplication;

import javax.swing.*;
import java.awt.*;

public class SingleFrameExample1 extends SingleFrameApplication {
    @Override
    protected Component createMainComponent() {
        JLabel label = new JLabel("Hello World");
        label.setFont(new Font("LucidaSans", Font.PLAIN, 32));
        return label;
    }

    public static void main(String[] args) {
        launch(SingleFrameExample1.class, args);
    }
}
