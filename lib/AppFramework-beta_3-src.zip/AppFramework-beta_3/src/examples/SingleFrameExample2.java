/*
* Copyright (C) 2006 Sun Microsystems, Inc. All rights reserved. Use is
* subject to license terms.
*/

package examples;

import org.jdesktop.application.SingleFrameApplication;

import javax.swing.*;
import java.awt.*;

/**
 * @author Hans Muller (Hans.Muller@Sun.COM)
 */
public class SingleFrameExample2 extends SingleFrameApplication {
    @Override
    protected Component createMainComponent() {
        JLabel label = new JLabel("JLabel");
        label.setFont(new Font("LucidaSans", Font.PLAIN, 32));
        return label;
    }

    @Override
    protected JMenuBar createJMenuBar() {
        JMenuBar bar = new JMenuBar();
        JMenu menu = new JMenu("JMenu");
        menu.add(new JMenuItem("JMenuItem"));
        menu.add(new JMenuItem("JMenuItem"));
        menu.add(new JMenuItem("JMenuItem"));
        bar.add(menu);
        return bar;
    }

    @Override
    protected JToolBar createJToolBar() {
        JToolBar toolBar = new JToolBar();
        toolBar.add(new JButton("JButton"));
        return toolBar;
    }

    public static void main(String[] args) {
        launch(SingleFrameExample2.class, args);
    }
}
